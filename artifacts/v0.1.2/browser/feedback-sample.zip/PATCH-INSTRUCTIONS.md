# Incremental review contract

Read feedback.json and the local screenshots. Return only a JSON patch matching patch-template.json. Preserve projectId and baseRevision. Address only listed pending review IDs and their target node IDs. Change scalar fields explicitly requested; respect every protectedProperties path AND effectiveProtectedProperties for the node (prefix restrictions cover descendants, including other unresolved reviews). Do not generate a replacement screen or project. Never change stable IDs. Do not approve your own changes. Import the patch in Studio; conflicts are rejected.

Allowed fields: frame.x/y/width/height; style.fill/stroke/strokeWidth/radius/color/fontSize/fontFamily/text/align/opacity; assetId; visible; layout.mode/gap/padding; buttonAssets.normal/hover/pressed. Check the current schema and node constraints.
