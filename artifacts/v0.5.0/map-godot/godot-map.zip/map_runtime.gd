extends Node2D

signal marker_entered(stable_id: String, marker_type: String)

var document: Dictionary
var blocked: Dictionary = {}
var actor_size := Vector2i.ONE
var node_mapping: Dictionary = {}
var player_cell := Vector2i.ZERO
var moving_to := Vector2i.ZERO
var route: Array = []
var moving := false
var preview_enabled := true
var cell_step := 0.16
@onready var map_root: Node2D = $Map
@onready var player: Node2D = $Map/Actors/Player

func iso(cell: Vector2) -> Vector2:
    return Vector2((cell.x - cell.y) * document.grid.tileWidth / 2.0, (cell.x + cell.y) * document.grid.tileHeight / 2.0)

func local_to_cell(point: Vector2) -> Vector2i:
    return Vector2i(roundi(point.x / document.grid.tileWidth + point.y / document.grid.tileHeight), roundi(point.y / document.grid.tileHeight - point.x / document.grid.tileWidth))

func walkable(cell: Vector2i) -> bool:
    if cell.x < 0 or cell.y < 0 or cell.x + actor_size.x > document.grid.width or cell.y + actor_size.y > document.grid.height:
        return false
    for x in range(cell.x, cell.x + actor_size.x):
        for y in range(cell.y, cell.y + actor_size.y):
            if blocked.has(Vector2i(x, y)):
                return false
    return true

func path_to(start: Vector2i, finish: Vector2i) -> Array:
    if not walkable(start) or not walkable(finish):
        return []
    var visited: Dictionary = {start: null}
    var queue: Array = [start]
    var head := 0
    while head < queue.size():
        var current: Vector2i = queue[head]
        head += 1
        if current == finish:
            var found: Array = []
            var cursor = finish
            while cursor != null:
                found.push_front(cursor)
                cursor = visited[cursor]
            return found
        for direction in [Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT, Vector2i.UP]:
            var next: Vector2i = current + direction
            if not visited.has(next) and walkable(next):
                visited[next] = current
                queue.append(next)
    return []

func _ready() -> void:
    document = JSON.parse_string(FileAccess.get_file_as_string("res://map.json"))
    for key in document.blocked:
        var parts = key.split(",")
        blocked[Vector2i(int(parts[0]), int(parts[1]))] = true
    var actor = document.get("playability", {}).get("actor", {"width": 1, "height": 1})
    actor_size = Vector2i(actor.width, actor.height)
    for object in document.objects:
        if object.blocking:
            var region = object.get("collision", {"x": 0, "y": 0, "width": object.footprint.width, "height": object.footprint.height})
            for x in range(int(object.x + region.x), int(object.x + region.x + region.width)):
                for y in range(int(object.y + region.y), int(object.y + region.y + region.height)):
                    blocked[Vector2i(x, y)] = true
    var mapping = JSON.parse_string(FileAccess.get_file_as_string("res://node-map.json"))
    node_mapping = mapping
    player_cell = Vector2i(mapping.spawn.x, mapping.spawn.y)
    preview_enabled = walkable(player_cell)
    player.visible = preview_enabled and mapping.actorVisible
    player.position = iso(Vector2(player_cell))
    if "--studio-verify" in OS.get_cmdline_user_args():
        call_deferred("verify_scene")

func _unhandled_input(event: InputEvent) -> void:
    if not preview_enabled:
        return
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        var target := local_to_cell(map_root.get_local_mouse_position())
        set_destination(target)
    if event is InputEventKey and event.pressed and not event.echo and not moving:
        if event.keycode == KEY_E:
            for marker in document.markers:
                if marker.type == "interaction" and absi(int(marker.x) - player_cell.x) + absi(int(marker.y) - player_cell.y) <= 1:
                    marker_entered.emit(marker.id, marker.type)
        var direction := Vector2i.ZERO
        match event.keycode:
            KEY_RIGHT, KEY_D: direction = Vector2i.RIGHT
            KEY_DOWN, KEY_S: direction = Vector2i.DOWN
            KEY_LEFT, KEY_A: direction = Vector2i.LEFT
            KEY_UP, KEY_W: direction = Vector2i.UP
        if direction != Vector2i.ZERO and walkable(player_cell + direction):
            route = [player_cell + direction]

func set_destination(target: Vector2i) -> void:
    # A click during a step starts its new path at the in-flight destination.
    # Starting at player_cell would queue that destination twice and cancel it.
    route = path_to(moving_to if moving else player_cell, target)
    if not route.is_empty():
        route.pop_front()

func _process(_delta: float) -> void:
    update_occlusion()
    if moving or route.is_empty() or not preview_enabled:
        return
    var next: Vector2i = route.pop_front()
    if not walkable(next) or absi(next.x - player_cell.x) + absi(next.y - player_cell.y) != 1:
        route.clear()
        return
    moving = true
    moving_to = next
    var tween := create_tween()
    tween.tween_property(player, "position", iso(Vector2(next)), cell_step)
    tween.finished.connect(func():
        player_cell = next
        moving = false
        for marker in document.markers:
            if marker.type != "interaction" and Vector2i(marker.x, marker.y) == player_cell:
                marker_entered.emit(marker.id, marker.type)
    )

func update_occlusion() -> void:
    for entry in node_mapping.get("objects", []):
        var region: Dictionary = entry.occlusion
        var sprite = get_node_or_null(NodePath(entry.path))
        if sprite != null:
            var covered: bool = region.fade and player_cell.x >= entry.cell.x + region.x and player_cell.y >= entry.cell.y + region.y and player_cell.x < entry.cell.x + region.x + region.width and player_cell.y < entry.cell.y + region.y + region.height
            sprite.modulate.a = 0.3 if covered and preview_enabled and player.visible else 1.0

func verify_scene() -> void:
    var result_path := "res://runtime-results.json"
    var screenshot_path := ""
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--studio-result="):
            result_path = arg.trim_prefix("--studio-result=")
        if arg.begins_with("--studio-screenshot="):
            screenshot_path = arg.trim_prefix("--studio-screenshot=")
    for frame in range(8):
        await get_tree().process_frame
    var mapping = JSON.parse_string(FileAccess.get_file_as_string("res://node-map.json"))
    var errors: Array = []
    var checks: Array = []
    for layer_entry in mapping.layers:
        var layer = get_node_or_null(NodePath(layer_entry.path))
        var passed: bool = layer is TileMapLayer and layer.get_meta("studio_id", "") == layer_entry.id and layer.visible == layer_entry.visible and layer.z_index == layer_entry.zIndex
        if passed:
            passed = layer.get_used_cells().size() == layer_entry.cells.size()
            for cell in layer_entry.cells:
                var coords := Vector2i(cell.x, cell.y)
                var expected := iso(Vector2(coords))
                if layer.position.distance_to(-Vector2(document.grid.tileWidth, document.grid.tileHeight) / 2.0) > 0.01 or (layer.map_to_local(coords) + layer.position).distance_to(expected) > 0.01 or layer.get_cell_source_id(coords) != cell.sourceId:
                    passed = false
        checks.append({"kind": "tile-layer", "id": layer_entry.id, "passed": passed})
        if not passed: errors.append("Tile layer mismatch: " + layer_entry.id)
    for object_entry in mapping.objects:
        var sprite = get_node_or_null(NodePath(object_entry.path))
        var passed: bool = sprite is Sprite2D and sprite.get_meta("studio_id", "") == object_entry.id and sprite.visible == object_entry.visible and sprite.z_index == object_entry.zIndex
        if passed:
            var size: Vector2 = sprite.texture.get_size() * sprite.scale
            passed = sprite.position.distance_to(Vector2(object_entry.position.x, object_entry.position.y)) < 0.01 and size.distance_to(Vector2(object_entry.size.x, object_entry.size.y)) < 0.01 and (sprite.offset * sprite.scale).distance_to(Vector2(object_entry.offset.x, object_entry.offset.y)) < 0.01
        checks.append({"kind": "sprite", "id": object_entry.id, "passed": passed})
        if not passed: errors.append("Object mismatch: " + object_entry.id)
    for collider in mapping.colliders:
        var body = get_node_or_null(NodePath(collider.path))
        var shape = body.get_node_or_null("Shape") if body != null else null
        var passed: bool = body is StaticBody2D and shape is CollisionPolygon2D and shape.polygon.size() == 4
        checks.append({"kind": "collision", "id": collider.id, "passed": passed})
        if not passed: errors.append("Collision missing: " + collider.id)
    for marker in mapping.markers:
        var node = get_node_or_null(NodePath(marker.path))
        var passed: bool = node != null and node.get_meta("studio_id", "") == marker.id and node.get_meta("studio_type", "") == marker.type
        checks.append({"kind": "marker", "id": marker.id, "passed": passed})
        if not passed: errors.append("Marker missing: " + marker.id)
    var occupancy: Array = []
    for y in range(int(document.grid.height)):
        for x in range(int(document.grid.width)):
            occupancy.append(walkable(Vector2i(x, y)))
    if occupancy != mapping.walkability:
        errors.append("Grid walkability differs from Studio model")
    if walkable(Vector2i(-1, 0)) or walkable(Vector2i(int(document.grid.width), 0)):
        errors.append("Map bounds permit walking outside")
    var physics_blocked := 0
    for y in range(int(document.grid.height)):
        for x in range(int(document.grid.width)):
            if not blocked.has(Vector2i(x, y)):
                continue
            var query := PhysicsPointQueryParameters2D.new()
            query.position = map_root.to_global(iso(Vector2(x, y)))
            query.collision_mask = 1
            query.collide_with_areas = false
            if get_world_2d().direct_space_state.intersect_point(query).is_empty():
                errors.append("Physics collision absent at " + str(Vector2i(x, y)))
            else:
                physics_blocked += 1
    var test_route: Array = []
    if not mapping.testPath.is_empty():
        for point in mapping.testPath: test_route.append(Vector2i(point.x, point.y))
        if path_to(test_route[0], test_route[-1]) != test_route:
            errors.append("Runtime path differs from Studio BFS path")
        player_cell = test_route[0]
        player.position = iso(Vector2(player_cell))
        cell_step = 0.1
        set_destination(test_route[-1])
        for frame in range(3):
            await get_tree().process_frame
            if moving: break
        if test_route.size() > 1 and not moving:
            errors.append("Movement never started")
        # Exercise a second click while a tween is in flight, not only idle walks.
        set_destination(test_route[-1])
        cell_step = 0.001
        var ticks := 0
        while (moving or not route.is_empty()) and ticks < 2000:
            await get_tree().process_frame
            ticks += 1
        if player_cell != test_route[-1] or player.position.distance_to(iso(Vector2(test_route[-1]))) > 0.01:
            errors.append("Player did not finish the walk route")
        # A queued blocked destination must be rejected by the actual movement loop.
        if not blocked.is_empty():
            var previous := player_cell
            route = [blocked.keys()[0]]
            await get_tree().process_frame
            await get_tree().process_frame
            if player_cell != previous: errors.append("Movement entered a blocked cell")
    if not $Map/Actors.y_sort_enabled or player.z_index != mapping.actorZ:
        errors.append("Foot-based actor sorting disabled")
    if player.visible != (walkable(Vector2i(mapping.spawn.x, mapping.spawn.y)) and mapping.actorVisible):
        errors.append("Actor layer visibility differs from Studio")
    for entry in mapping.objects:
        var sprite = get_node(NodePath(entry.path))
        if sprite.z_index != entry.zIndex: errors.append("Object layer band differs from Studio: " + entry.id)
    # Return to the true spawn so the capture is reproducible.
    player_cell = Vector2i(mapping.spawn.x, mapping.spawn.y)
    player.position = iso(Vector2(player_cell))
    route.clear()
    if "--studio-map-only" in OS.get_cmdline_user_args():
        player.visible = false
    update_occlusion()
    var screenshot := {"requested": not screenshot_path.is_empty(), "written": false}
    if not screenshot_path.is_empty():
        if DisplayServer.get_name() == "headless":
            errors.append("A graphical display is required for map screenshots")
        else:
            await RenderingServer.frame_post_draw
            await RenderingServer.frame_post_draw
            var image := get_viewport().get_texture().get_image()
            var error := image.save_png(screenshot_path)
            screenshot = {"requested": true, "written": error == OK, "width": image.get_width(), "height": image.get_height()}
            if error != OK: errors.append("Screenshot save failed")
    var result := {"passed": errors.is_empty(), "godot": Engine.get_version_info().string, "display": DisplayServer.get_name(), "projectId": document.id, "revision": document.revision, "checks": checks, "cellCount": mapping.cellCount, "walkabilityCells": occupancy.size(), "physicsBlockedCells": physics_blocked, "walkedSteps": maxi(0, test_route.size() - 1), "ySortEnabled": $Map/Actors.y_sort_enabled, "errors": errors, "screenshot": screenshot}
    var file := FileAccess.open(result_path, FileAccess.WRITE)
    if file == null:
        push_error("Cannot write map verification result")
        get_tree().quit(2)
        return
    file.store_string(JSON.stringify(result, "  "))
    file.close()
    print("STUDIO_MAP_VERIFY passed=" + str(result.passed))
    get_tree().quit(0 if result.passed else 1)
