@tool
extends Sprite2D

@export var studio_source: Texture2D
@export var studio_size: Vector2 = Vector2(64, 64)
@export var studio_anchor: Vector2 = Vector2(0.5, 1.0)
@export var studio_crop: Rect2i = Rect2i()
@export var studio_sort_offset: Vector2 = Vector2.ZERO

func _ready() -> void:
    if studio_source == null:
        return
    var image = studio_source.get_image()
    if studio_crop.size != Vector2i.ZERO:
        if not Rect2i(Vector2i.ZERO, image.get_size()).encloses(studio_crop):
            push_error("Map object atlas region exceeds image bounds")
            return
        image = image.get_region(studio_crop)
    # A Sprite2D transform preserves fractional display sizes without rounding.
    texture = ImageTexture.create_from_image(image)
    centered = false
    scale = studio_size / Vector2(image.get_size())
    offset = -Vector2(image.get_size()) * studio_anchor - studio_sort_offset / scale
