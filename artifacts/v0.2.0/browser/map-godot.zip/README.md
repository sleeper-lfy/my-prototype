# Game UI Studio — Godot map export

Open project.godot with Godot 4.3 or newer, then run the project (F6 runs map.tscn). Click a cell to walk, or use WASD/arrow keys along grid axes. The red-caped preview character sorts with buildings and trees by its feet within the configured actor layer.

Terrain uses native, editable TileMapLayer nodes and TileSet atlas sources. Objects are Sprite2D nodes; studio_size, studio_anchor and studio_crop preserve image dimensions and anchors. The @tool display scripts normalize original textures in the editor and runtime. Layers follow the Studio back-to-front order: each terrain band is followed by its object band; foot sorting applies within that band. The configured actor layer determines the player band. Asset footprint defaults are retained in map.json; each placed object has its own occupied-cell footprint and native collision polygon. Every map layer, object and marker carries studio_id metadata; node-map.json maps it to a Godot node path. Cell identity is layer ID plus grid coordinate.

StaticBody2D footprint polygons and blocked cells are real physics shapes on collision layer 1. Hidden layers retain collision, matching Studio. Exit/trigger Area2D nodes use layer 2; the preview emits marker_entered(id,type), without inventing gameplay or teleport destinations. Grid navigation is not a NavigationRegion2D bake.

Functional validation, export fidelity and art approval are separate. Read export-warnings.json. This is a flat isometric 2D map, not a height-aware 3D terrain editor.

Verify with your Godot executable:

```text
godot --headless --editor --path "<EXPORT>" --import
godot --path "<EXPORT>" --audio-driver Dummy --rendering-method gl_compatibility -- --studio-verify --studio-result=<ABS_RESULT_JSON> --studio-screenshot=<ABS_PNG>
```

Use absolute output paths and a graphical display for screenshots. Headless runs validate scene structure, all cells, walkability, physics blockers and actual character movement but cannot validate a rendered image.
