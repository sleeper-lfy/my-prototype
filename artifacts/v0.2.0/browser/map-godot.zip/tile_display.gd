@tool
extends TileMapLayer

# Normalize display size and optional atlas crop from the unmodified source texture.
# Runs in the editor too, so imported/custom tiles have the same dimensions there.
func _ready() -> void:
    if tile_set == null:
        return
    for index in range(tile_set.get_source_count()):
        var source = tile_set.get_source(tile_set.get_source_id(index))
        if not source is TileSetAtlasSource or source.has_meta("studio_normalized"):
            continue
        var image = source.texture.get_image()
        var region: Rect2i = source.get_meta("studio_crop")
        if region.size != Vector2i.ZERO:
            if not Rect2i(Vector2i.ZERO, image.get_size()).encloses(region):
                push_error("Map tile atlas region exceeds image bounds")
                continue
            image = image.get_region(region)
        var display: Vector2i = source.get_meta("studio_size")
        if image.get_size() != display:
            image.resize(display.x, display.y, Image.INTERPOLATE_LANCZOS)
        source.texture = ImageTexture.create_from_image(image)
        source.texture_region_size = display
        source.set_meta("studio_normalized", true)
