import { readFile } from 'node:fs/promises';
import { validateProject } from './model.mjs';
try {
  if (process.argv.length !== 3) throw new Error('Usage: node validate.mjs result.project.json');
  const raw = await readFile(process.argv[2]);
  if (raw.length > 25 * 1024 * 1024) throw new Error('Project exceeds the 25 MiB import limit.');
  const project = validateProject(JSON.parse(raw.toString('utf8').replace(/^\uFEFF/, '')));
  console.log(JSON.stringify({ valid: true, projectId: project.id, components: project.nodes.length, assets: project.assets.length, checks: ['native schema and references'], notChecked: ['asset existence in target Studio', 'Godot runtime', 'visual quality'] }, null, 2));
} catch (error) { console.error(error.message); process.exitCode = 1; }
